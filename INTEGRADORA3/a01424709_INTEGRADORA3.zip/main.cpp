/*
    Made by: Armando Arredondo Valle
    Date: 30/10/2022
 */
#include <iostream>
#include <string>
#include <fstream>
#include "Binnacle.h"
#include "Node.h"
#include "NodePtr.h"
#include "BST.h"
#include "AVL.h"
#include "NodeAVL.h"
#include <vector>
using namespace std;

BST binnacleList;
AVL avlTree;
//vector<Binnacle> binnacleVector;
int main() {
    int counter = 0, counter2 = 0;
    int answer = 0;
    cout << "==============================\n";
    cout << "Bienvenido a la bitacora de seguridad\n";
    cout << "==============================\n";
    cout << "Please insert the number of binnacle you want to display: ";
    cin >> answer;
    cout << " \n";
    // validate if the user input is a number
    while (cin.fail()) {
        cout << "==============================\n";
        cout << "Please insert a number\n";
        cout << "==============================\n";
        cout << " \n";
        cin.clear();
        cin.ignore(256, '\n');
        cout << "Please insert the number of binnacle you want to display: ";
        cin >> answer;
        cout << " \n";
    }
    while(answer > 50){
        cout << "Please insert a number less than 50: ";
        cin >> answer;
    }

    string sentences;
    ifstream file;
    file.open("C:\\Users\\arman\\OneDrive\\Escritorio\\CLASE ESTRUCTURA DE DATOS\\INTEGRADORA3\\bitacora.txt");
    if (file.is_open()){
        do {
            getline(file,sentences);
            counter2++;
            string IP;
            string port;
            int spaces = 0;
            string word;
            for (int i = 0; i < sentences.size(); i++) {
                if (sentences[i] == ' ') {
                    spaces++;
                    if (counter == 3){
                        IP = word;
                        counter++;
                    } else {
                        counter++;
                    }
                    word = "";
                    if (spaces == 4){
                        counter = 0;
                        break;
                    }
                } else {
                    word += sentences[i];
                }
            }
            port = IP.substr(IP.find(":")+1);
            IP = IP.substr(0,IP.find(":"));
            Binnacle bitacora(IP, port);
            //binnacleList.insertInOrder(bitacora);
            binnacleList.insertInOrder(bitacora);

            bool height = false;
            avlTree.setRaiz(avlTree.insertaAVL(avlTree.getRaiz(), bitacora, height));
            height = false;
        } while (!file.fail() && counter2 < answer);
    }else {
        cout << "Error, file not found, please check the path or add the file." << "\n";
    }
    cout << "==============================\n";
    cout << "Printing the binnacle in PreOrder\n";
    cout << "==============================\n";
    binnacleList.preOrder(binnacleList.getRoot());
    cout << "==============================\n";
    cout << "Printing the binnacle in PosOrder\n";
    cout << "==============================\n";
    binnacleList.posOrder(binnacleList.getRoot());
    cout << "==============================\n";
    cout << "Deleting a node\n";
    cout << "==============================\n";
    binnacleList.deleteNode(Binnacle("108.57.27.85","5491"));
    //binnacleList.deleteNode(Binnacle("423.2.230.77","6166"));
    binnacleList.posOrder(binnacleList.getRoot());
    cout << "==============================\n";
    cout << "Deleting a deleteOneChild\n";
    cout << "==============================\n";
    binnacleList.deleteOneChild(binnacleList.getRoot(), binnacleList.getRoot()->getRight());
    binnacleList.posOrder(binnacleList.getRoot());
    cout << "==============================\n";
    cout << "Deleting a leaf\n";
    cout << "==============================\n";
    binnacleList.deleteLeaf(binnacleList.getRoot(), binnacleList.getRoot());
    binnacleList.preOrder(binnacleList.getRoot());
    cout << " \n";
    cout << " \n";
    cout << " \n";
    cout << "===============================================================\n";
    cout << "                 AVL TREE\n";
    cout << "===============================================================\n";
    cout << " \n";
    cout << " \n";
    cout << " \n";
    cout << "==============================\n";
    cout << "Printing the AVL in PreOrder\n";
    cout << "==============================\n";
    avlTree.preorden(avlTree.getRaiz());
    cout << "==============================\n";
    cout << "Printing the AVL in InOrder\n";
    cout << "==============================\n";
    avlTree.inorden(avlTree.getRaiz());

    return 0;
}
